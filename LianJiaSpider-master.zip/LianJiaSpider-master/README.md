##链家爬虫

爬取北京地区链家历年二手房成交记录。[链家爬虫](http://lanbing510.info/2016/03/15/Lianjia-Spider.html)一文的全部代码，包括链家模拟登录代码。

###爬取数据的部分截图

![Aaron Swartz](https://github.com/lanbing510/LianJiaSpider/raw/master/screenshots/lianjia.jpg)